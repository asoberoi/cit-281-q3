const students = [
  {
    id: 1,
    last: "Last1",
    first: "First1",
  },
  {
    id: 2,
    last: "Last2",
    first: "First2",
  },
  {
    id: 3,
    last: "Last3",
    first: "First3",
  }
];


const fastify = require("fastify")();


fastify.get("/cit/student", (request, reply) => {
reply
  .code(200)
  .header("Content-Type", "application/json; charset=utf-8")
  .send(students);
});


fastify.get("/cit/student/:id", (request, reply) => {
  let studentIDFromClient = request.params.id;

   let studentRequested = null;

  for (studentInArray of students) {
      if (studentInArray.id == studentIDFromClient) {
          studentRequested = studentInArray
          break;
      }
  }

  

  if( studentRequested != null) {
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(studentRequested);
  } else {
      reply
      .code(404)
      .header("Content-Type", "text/html; charset=utf-8")
      .send("<h1>No student with that given ID was found.</h1>");
  }
});


fastify.get("*", (request, reply) => {
  reply
    .code(200)
    .header("Content-Type", "text/html; charset=utf-8")
    .send("<h1>At Unmatched Route!</h1>");
});


fastify.post("/cit/student/add", (request, reply) => {

  let userData = JSON.parse(JSON.stringify(request.body));
  console.log(userData)
  const { last, first } = userData;
  
  
  
  let maxId = Math.max.apply(Math, students.map(function(students) {
    return students.id; 
  }));
  

  
  let newID = maxId + 1
  
  
  let newUser = { newID, last, first }
 
  students.push(newUser)
  
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(newUser); 
});


const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
if (err) {
  console.log(err);
  process.exit(1);
}
console.log(`Server listening on ${address}`);
}); 